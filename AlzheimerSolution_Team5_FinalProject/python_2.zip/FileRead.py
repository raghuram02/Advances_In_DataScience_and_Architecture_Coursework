import os.path
import shutil
from PIL import Image

path= 'C:/MRI/disc1/OAS1_0'
path2='_MR1/PROCESSED/MPRAGE/T88_111/OAS1_0'
path3='_MR2/PROCESSED/MPRAGE/T88_111/OAS1_0'

for l in xrange(100,999):
   # print path+str(l)+path2+str(l)+'_MR1_mpr_n4_anon_111_t88_gfc_cor_110.gif'
    if os.path.exists(path+str(l)+path2+str(l)+'_MR1_mpr_n4_anon_111_t88_gfc_cor_110.gif')==True & os.path.exists(path+str(l)+path3+str(l)+'_MR2_mpr_n4_anon_111_t88_gfc_cor_110.gif')==True:
        print l
        print 'true'
        if not os.path.exists('C:/Processed Images/Patient'+str(l)):
            os.makedirs('C:/Processed Images/Patient'+str(l))
        if os.path.exists(path+str(l)+path2+str(l)+'_MR1_mpr_n4_anon_111_t88_gfc_cor_110.gif')==True:
            shutil.copyfile(path+str(l)+path2+str(l)+'_MR1_mpr_n4_anon_111_t88_gfc_cor_110.gif', 'C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI1.gif')
            Image.open('C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI1.gif').convert('RGB').save('C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI1.jpg')

        if os.path.exists(path+str(l)+path3+str(l)+'_MR2_mpr_n4_anon_111_t88_gfc_cor_110.gif')==True:
            shutil.copyfile(path+str(l)+path3+str(l)+'_MR2_mpr_n4_anon_111_t88_gfc_cor_110.gif', 'C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI2.gif')
            Image.open('C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI2.gif').convert('RGB').save('C:/Processed Images/Patient'+str(l)+'/Patient'+str(l)+'_MRI2.jpg')

            
