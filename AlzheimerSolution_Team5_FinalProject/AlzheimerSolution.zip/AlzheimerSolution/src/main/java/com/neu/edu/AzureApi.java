package com.neu.edu;

import java.util.Iterator;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class AzureApi {
	public static String apiurl;
    public static String apikey;
    
    // Calling random Forest model
    public String callClassification(String json) {
    	System.out.println("calling classification: ");
    	
    	
    	
    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b2c9e122af944685851e8622d46c7d1a/services/2dc58764612943b08d54f9d5f389ef50/execute?api-version=2.0&details=true";
    	apikey = "+d/kt9h9R6XwqUvR//FrixpHwcT+oniPeXCQQy0dcWquJ5X3BI8l79+PE6jRdtfTfZ4QCDpYU343dmF6O3BXSQ==";
    		    	
    	
    	System.out.println("Api url");
    	
    	String result = rrsHttpPost(json);
    	
    	System.out.println("Api url"+result);
    	return retrieveOutput(result);
    }
    
   
    /**
     * Call REST API for retrieving prediction from Azure ML 
     * @return response from the REST API
     */	
    public String rrsHttpPost(String jsonBody) {
        
        HttpPost post;
        HttpClient client;
        StringEntity entity;
        
        try {
        	
            // create HttpPost and HttpClient object
            post = new HttpPost(apiurl);
            client = HttpClientBuilder.create().build();
            
            // setup output message by copying JSON body into 
            // apache StringEntity object along with content type
            entity = new StringEntity(jsonBody, HTTP.UTF_8);
            entity.setContentEncoding(HTTP.UTF_8);
            entity.setContentType("text/json");

            // add HTTP headers
            post.setHeader("Accept", "text/json");
            post.setHeader("Accept-Charset", "UTF-8");
        
            // set Authorization header based on the API key
            post.setHeader("Authorization", ("Bearer "+apikey));
            post.setEntity(entity);

            // Call REST API and retrieve response content
            HttpResponse authResponse = client.execute(post);
            
            return EntityUtils.toString(authResponse.getEntity());
            
        }
        catch (Exception e) {   
            System.out.println("Error occurred while calling the service!!");
            return e.toString();
        }
    }	 
    
    public String retrieveOutput(String input) {
		
    	try {
	    	JSONParser parser = new JSONParser();	    	
	    	Object obj = parser.parse(input);	 
	    	
			JSONObject json = (JSONObject) obj;
							
		   JSONObject result = (JSONObject) json.get("Results");
		   System.out.println(json.get("Results"));
			
	       JSONObject output1 = (JSONObject)result.get("output1");
	       System.out.println(result.get("output1"));	
	       
	       JSONObject value = (JSONObject)output1.get("value");
	       System.out.println(output1.get("value"));
	        
	       String res = null; 
	       JSONArray strArray = (JSONArray)value.get("Values");				
	       Iterator<Object> itr = strArray.iterator();
		
			
			while(itr.hasNext()) {
				res = itr.next().toString();
				break;
			}
			
			StringBuilder sb = new StringBuilder();
			sb.append(res);
			
			String s = res.substring(2,sb.indexOf("]"));				
			
			String output =	s.substring(0,s.lastIndexOf('"'));
		 
			System.out.println(output);
			return output;
    	}
    	catch(Exception e) {
    		System.out.println("Error while parsing output!!");
    		e.printStackTrace();;
    	}
    	
    	return null;
    }

}
