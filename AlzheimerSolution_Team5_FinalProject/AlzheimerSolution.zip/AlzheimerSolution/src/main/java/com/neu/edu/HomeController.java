package com.neu.edu;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.python.util.PythonInterpreter;
import org.python.core.PyException;
import org.python.core.PyInstance;
import org.python.core.PyInteger;
import org.python.core.PyObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	final static String apikey = "+d/kt9h9R6XwqUvR//FrixpHwcT+oniPeXCQQy0dcWquJ5X3BI8l79+PE6jRdtfTfZ4QCDpYU343dmF6O3BXSQ==";
    final static String apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b2c9e122af944685851e8622d46c7d1a/services/2dc58764612943b08d54f9d5f389ef50/execute?api-version=2.0&details=true";
    String jsonString;
    
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "/neurogen.htm", method = RequestMethod.GET)
	public String neurogen(Locale locale, Model model) {
		return "neurogen";
	}
	
	@RequestMapping(value = "/neurotest.htm", method = RequestMethod.GET)
	public String neurotest(Locale locale, Model model) {
		return "neurotest";
	}
	
	@RequestMapping(value = "/prediction.htm", method = RequestMethod.GET)
	public String prediction(Locale locale, Model model) {
		return "prediction";
	}
	
	@RequestMapping(value = "/model.htm", method = RequestMethod.GET)
	public String model(Locale locale, Model model) {
		return "model";
	}
	
	@RequestMapping(value = "/main.htm", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "index";
	}
	
	@RequestMapping(value="/showChart.htm", method = RequestMethod.GET)
	public String initializeForm(Locale locale1, Model model1) {
		System.out.println("inside method");
		return "charts";
	}
	

	
	@RequestMapping(value = "/getData.htm", method = RequestMethod.POST)
	public ModelAndView getData(HttpServletRequest request, HttpServletResponse response) {		
		
		ModelAndView mv= new ModelAndView();
		mv.setViewName("prediction"); 
		
		String protein_syn1 = request.getParameter("protein_syn");
		String faq1 = request.getParameter("faq");
		String size_diff1 = request.getParameter("size_diff");
		
		System.out.println("All values");
		System.out.println(protein_syn1);
		System.out.println(faq1);
		System.out.println(size_diff1);
		
		
		String jsonString = null;
		
		int protein_syn = Integer.parseInt(protein_syn1);
		double FAQ = Double.parseDouble(faq1);
		double size_diff = Double.parseDouble(size_diff1);			
		
		//System.out.println(x + " " + y);	
			
		
		try {

			/*creating json from form values */
			
			JSONObject obj = new JSONObject();
			JSONObject inputs = new JSONObject();
			JSONObject input = new JSONObject();
			
			JSONArray columnName = new JSONArray();
			columnName.add("protein_syn");
			columnName.add("FAQ");
			columnName.add("size_diff");
			columnName.add("Alzheimer_flag");
			columnName.add("patient_id");
			
			JSONArray allValues = new JSONArray();
			JSONArray value = new JSONArray();
			value.add(protein_syn);
			value.add(FAQ);
			value.add(size_diff);
			value.add(0);
			value.add(0);
			allValues.add(value);
						
			input.put("ColumnNames", columnName);
			input.put("Values", allValues);
			inputs.put("input1", input);
			obj.put("Inputs", inputs);
	
			System.out.println("print the value of json "+obj);
			
			//converting json to string
			jsonString = obj.toString(); 
		}
		catch(Exception e) {
			System.out.println("Error occurred!!" + e);
		}		
		
		//Creating instance of azure class
		AzureApi azureApi = new AzureApi();		
		
		String res = null;
		
		
		res = azureApi.callClassification(jsonString);
		
		if(res != null) {
			System.out.println("Result of web service :" + res);	
			
			System.out.println("inside azure api");
			
			mv.addObject("output",res);
		}
		else {
			System.out.println("Error");			
			mv.addObject("error","invalid");	
			return mv;
		}
						
		return mv;
	}
	
	@RequestMapping(value = "/calculateData.htm", method = RequestMethod.POST)
	public String calculateData(HttpServletRequest request, HttpServletResponse response) throws PyException{		
		
		HttpSession sess = request.getSession();
		PythonInterpreter interpreter = new PythonInterpreter();
		String protein_syn1 = request.getParameter("protein_syn");
		String faq1 = request.getParameter("faq");
		String size1 = request.getParameter("size_diff");
//		String mri_scan1 = request.getParameter("mri_scan1");
//		String mri_scan2 = request.getParameter("mri_scan2");
		
		System.out.println("All values");
		System.out.println(protein_syn1);
		System.out.println(faq1);
		System.out.println(size1);
//		System.out.println(mri_scan1);
//		System.out.println(mri_scan2);
		
		interpreter.execfile("/var/lib/tomcat7/webapps/AlzheimerSolution/MRIreadwfunc.py");
		PyObject str = interpreter.eval("repr(compSizediff(mri_scan1,mri_scan2))");
		System.out.println(str.toString());
		sess.setAttribute("val", str.__len__());
		
		return "true";
	}
	
}
